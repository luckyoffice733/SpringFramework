package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.exception.CustomerNotFoundException;
import com.training.service.CustomerService;

@SpringBootApplication
public class DemoOnSpringBootDataJpaWithExceptionsApplication implements CommandLineRunner{

	@Autowired
	private CustomerService cService;
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootDataJpaWithExceptionsApplication.class, args);
	}
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		
		/*
		 * Customer c = new Customer(); c.setEmailId("venky01@cg.com");
		 * c.setName("venky");
		 * 
		 * String dob ="1975-09-24"; LocalDate ld = LocalDate.parse(dob);
		 * c.setDateOfBirth(ld);
		 * 
		 * //calling add method from the service layer Long id =cService.addCustomer(c);
		 * System.out.println("Record Inserted Successfully");
		 */
		
		//search customer based on id
		/*
		 * try { Customer cobj=cService.searchCustomerById(11);
		 * System.out.println("Search Record Found :"); System.out.println(cobj); }catch
		 * (CustomerNotFoundException ce) { System.err.println(ce.getMessage()); //
		 * TODO: handle exception }
		 */
		
		//delete
		 try {
		        cService.deleteCustomer(4);
			  }catch (CustomerNotFoundException ce) {
				  System.err.println(ce.getMessage());
				// TODO: handle exception
			}
		
		/*
		 * //update Customer cup = new Customer(); cup.setCustomerId(1L); String dob
		 * ="2003-11-01"; LocalDate ld = LocalDate.parse(dob); cup.setDateOfBirth(ld);
		 * cup.setEmailId("sai@Delinfotech.com"); cup.setName("sai");
		 * 
		 * cService.updateCustomer(cup);
		 */
		
		//get all the customers records
		/*
		 * List<Customer> al= cService.getAllCustomers();
		 * System.out.println("Customer Details are :");
		 * al.forEach(System.out::println);
		 */
		
	}
	

}
