package com.training.service;

import java.util.List;

import com.training.entity.Customer;
import com.training.exception.CustomerNotFoundException;

public interface CustomerService {

	public Long addCustomer(Customer cust);
	public List<Customer> getAllCustomers()throws CustomerNotFoundException;
	public Customer searchCustomerById(long id)throws CustomerNotFoundException;
	public void deleteCustomer(long id)throws CustomerNotFoundException;
	public void updateCustomer(Customer cust)throws CustomerNotFoundException;
}
