package com.training.service;

import java.time.LocalDate;
import java.util.List;

import com.training.entity.Customer;

public interface CustomerService {

	public Long addCustomer(Customer cust);
	public List<Customer> getAllCustomers();
	public Customer searchCustomerById(long id);
	public void deleteCustomer(long id);
	public void updateCustomer(Customer cust);
	public Customer searchCustomerByEmail(String em);
	public Customer searchCustomerByDobAndName(LocalDate dt,String em);
	public List<Customer> searchCustomerByDobOrName(LocalDate dt,String em);
	public List<Customer> searchCustomerNameUsingLike(String em);
}
