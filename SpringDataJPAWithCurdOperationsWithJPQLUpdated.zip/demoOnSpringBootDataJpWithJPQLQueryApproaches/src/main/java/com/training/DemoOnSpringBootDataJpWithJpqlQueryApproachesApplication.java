package com.training;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.entity.Customer;
import com.training.service.CustomerService;

@SpringBootApplication
public class DemoOnSpringBootDataJpWithJpqlQueryApproachesApplication  implements CommandLineRunner{

	@Autowired
	private CustomerService customerService;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootDataJpWithJpqlQueryApproachesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	
		String em="smith1@cg.com";
		Customer  cobj=customerService.searchCustomerByEmail(em);
		System.out.println("Searching based on email");
		System.out.println(cobj);
		
	    LocalDate ld = LocalDate.parse("1975-09-24");
		Customer  cobj1=customerService.searchCustomerByDobAndName(ld,"venky");
		System.out.println("Searching based on DOB and Name");
		System.out.println(cobj1);
		
		  LocalDate ld1 = LocalDate.parse("1975-09-24");
			List<Customer>  cobj2=customerService.searchCustomerByDobOrName(ld1,"smith James");
			System.out.println("Searching based on DOB OR Name");
			 cobj2.forEach(System.out::println);
			 
				List<Customer>  cobj3=customerService.searchCustomerNameUsingLike("s%");
				System.out.println("Searching based on like operator");
				 cobj3.forEach(System.out::println);
			
		
		
	}

}
