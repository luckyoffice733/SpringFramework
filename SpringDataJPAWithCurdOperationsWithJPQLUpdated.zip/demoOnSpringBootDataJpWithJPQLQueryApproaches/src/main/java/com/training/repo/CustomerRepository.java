package com.training.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.training.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long>{

	//custom method to search record based on emailId
	
	 Customer  findByEmailId(String em);
	 
	//create a customer Query method to fetch the data using dateOfBirth and name fields;
     Customer findByDateOfBirthAndName(LocalDate dt,String name);
	 
	//create a customer Query method to fetch the data using dateOfBirth or name fields;
     List<Customer> findByDateOfBirthOrName(LocalDate dt,String name);
    
     List<Customer> findByNameLike(String name);
     
     //Using @Query Annotation
     
     @Query("Select c from Customer c where c.emailId=?1")
     Customer customerRecordUsingEmail(String email);
     
     @Query("select c from Customer c where name like ?1")
     List<Customer>  customerDataUsingPattern(String name); //like //"s%"
     //named parameter
     @Query("Select c from Customer c where c.emailId=:a")
     Customer customerRecordUsingEmailUsingNamedParameter(@Param("a")  String email);
     
     
     
}
