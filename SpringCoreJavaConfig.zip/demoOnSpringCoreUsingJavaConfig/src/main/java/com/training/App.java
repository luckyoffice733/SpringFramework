package com.training;

/**
 * Hello world!
 *
 */
public class App implements MyApp
{

	String msg;
	
	
	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}


	@Override
	public String sayHello() {
		
		// TODO Auto-generated method stub
      return "welcome to spring framework "+this.msg;
	}
	
	/*
	 * public static void main(String[] args) { MyApp m = new App();
	 * System.out.println(m.sayHello("raju"));
	 * 
	 * 
	 * }
	 */
	
}
