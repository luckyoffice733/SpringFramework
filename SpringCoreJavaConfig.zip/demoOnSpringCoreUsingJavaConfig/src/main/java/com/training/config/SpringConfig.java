package com.training.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.training.App;

@Configuration
public class SpringConfig {
      
	  @Bean("t1")
	  public App getAppObject() {
		  App app = new App();
		  app.setMsg("Working with java configuration");
		  return app;
	  }
	
	
}
