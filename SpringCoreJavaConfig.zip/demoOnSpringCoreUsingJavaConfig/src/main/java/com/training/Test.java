package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.SpringConfig;

public class Test {
	
	public static void main(String[] args) {
		
		ApplicationContext context= new AnnotationConfigApplicationContext(SpringConfig.class);
		
	App aobj=	context.getBean(App.class,"t1");
		String m1 = aobj.sayHello();
		System.out.println(m1);
		
		
		
		
		
	}

}
