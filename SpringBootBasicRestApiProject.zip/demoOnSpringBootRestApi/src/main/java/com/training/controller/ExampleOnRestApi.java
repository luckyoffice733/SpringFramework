package com.training.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/example")
public class ExampleOnRestApi { //server port:8080
      
	//http://localhost:8000/<projectName>/show
	//http://localhost:8080/msg -url --endpoints url
	@GetMapping("/msg")  
	public String greet() {
		return "welcome to SPring Boot RestAPI from getMapping request";
	}
	
	@PostMapping("/msg")
	public String greet1() {
		return "welcome to SPring Boot RestAPI from postmapping request";
	}
	
	@PutMapping("/msg")
	public String greet2() {
		return "welcome to SPring Boot RestAPI from put Mapping request";
	}
	
	@DeleteMapping("/msg")
	public String greet3() {
		return "welcome to SPring Boot RestAPI from Delete mapping request";
	}
	
	
	@GetMapping("/show") //http://localhost:8080/show
	public String greet4() {
		return "welcome to SPring Boot greet4 method in spring boot rest api";
	}
	
}
