package com.training.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.CustomerDTO;

@RestController
@RequestMapping("/customer")
public class CustomerApi {

	//http://localhost:8000/customer/show
	@GetMapping("/msg")  
	public String sayHello() {
		return "welcome to CustomerApi";
	}
	
	@PostMapping("/insert") //http://localhost:8000/customer/insert
	public String getFullName(@RequestParam("fn") String fname,@RequestParam("ln") String lname) {
		return "FullName is : "+fname+" "+lname;
	}
	
	
	@PostMapping("/empInsert/{fn1}/{ln1}") //http://localhost:8000/customer/empInsert/smith/mark
	public String getEmployeeFullName(@PathVariable("fn1") String fname,@PathVariable("ln1") String lname) {
		return "Employee FullName is : "+fname+" "+lname;
	}
	
	//http://localhost:8000/customer/emp
	@PostMapping("/emp")  //{key:value,key:value} ---json
	public CustomerDTO insertCustomer(@RequestBody CustomerDTO cust) {
		
		return cust;
		
	}
	
	
}
