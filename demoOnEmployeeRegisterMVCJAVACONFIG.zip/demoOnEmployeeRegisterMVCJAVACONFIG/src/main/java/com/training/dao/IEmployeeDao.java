package com.training.dao;

import com.training.bean.EmployeeDTO;

public interface IEmployeeDao {
	
	public int saveEmployee(EmployeeDTO edto);

}
