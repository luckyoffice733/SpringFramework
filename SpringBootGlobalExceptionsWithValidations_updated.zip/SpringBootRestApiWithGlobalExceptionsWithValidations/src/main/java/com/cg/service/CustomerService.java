package com.cg.service;

import java.util.List;

import com.cg.entity.Customer;
import com.cg.exception.CustomerNotFoundException;

public interface CustomerService {
	
     public Long addCustomer(Customer cust);
     public List<Customer> getAllCustomers()throws CustomerNotFoundException;
     public Customer getCustomerById(Long id)throws CustomerNotFoundException;
     public void deleteCustomer(Long id) throws CustomerNotFoundException;
     public void updateCustomer(Long id, String email)throws CustomerNotFoundException;
}
