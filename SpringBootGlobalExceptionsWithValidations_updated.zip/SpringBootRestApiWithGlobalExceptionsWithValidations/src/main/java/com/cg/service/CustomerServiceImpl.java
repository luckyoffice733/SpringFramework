package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Customer;
import com.cg.exception.CustomerNotFoundException;
import com.cg.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepo customerRepo;

	@Override
	public Long addCustomer(Customer cust) {
		Customer customer=  customerRepo.save(cust);
		
		return customer.getCustomerId();
	}

	@Override
	public List<Customer> getAllCustomers() throws CustomerNotFoundException{
	
		List<Customer> lst =customerRepo.findAll();
		if(lst.isEmpty()) {
			throw new CustomerNotFoundException("Service.CUSTOMERS_NOT_FOUND");
		}
		
		return lst;
		
	}

	@Override
	public Customer getCustomerById(Long id)throws CustomerNotFoundException {
	
	Optional<Customer> optal=customerRepo.findById(id);
	 Customer cust = optal.orElseThrow(()-> new CustomerNotFoundException("Service.CUSTOMER_NOT_FOUND"));
	/*
	 * if(optal.isPresent()) { return optal.get(); }else { throw new
	 * CustomerNotFoundException("Customer Not Found Based On Id"); }
	 */
	 return cust;
	
	}

	@Override
	public void deleteCustomer(Long id) throws CustomerNotFoundException {
	Optional<Customer> optial=	 customerRepo.findById(id);
		
	Customer cust = optial.orElseThrow(() -> new CustomerNotFoundException("Service.CUSTOMER_NOT_FOUND"));
	
	 customerRepo.deleteById(id);
	
	}

	@Override
	public void updateCustomer(Long id, String email) throws CustomerNotFoundException {
		Optional<Customer> optial=	 customerRepo.findById(id);
		Customer cust = optial.orElseThrow(() -> new CustomerNotFoundException("Service.CUSTOMER_NOT_FOUND"));
		
		cust.setEmail(email);
		customerRepo.save(cust);
		
	}

}
