package com.training.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/provider")
public class ProviderApi {
	
	@GetMapping("/show")  //http://localhost:8091/provider/show
	public String showMsg() {
		return "From the ProviderMS1 - Welcome to microservices";
	}

}
