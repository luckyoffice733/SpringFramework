package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Product;
import com.cg.exception.ProductNotFound;
import com.cg.repo.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Long addProduct(Product product) {
		Product prod=productRepository.save(product);
		return prod.getProductId();
	}

	@Override
	public List<Product> getAllProducts() throws ProductNotFound {
	
		List<Product> records = productRepository.findAll();
		if(records.isEmpty()) {
			throw new ProductNotFound("Products Not Found");
		}
		
		return records;
		
	}

	@Override
	public Product getProductById(Long id) throws ProductNotFound {
	Optional<Product>  option=	productRepository.findById(id);
	Product product = option.orElseThrow(() -> new ProductNotFound("Product Not Found By Id"));
		
		return product;
	}

	@Override
	public Product updateProductQuantity(Long id, Long qty) throws ProductNotFound {
		Optional<Product>  option=	productRepository.findById(id);
		Product prod= null;
		if(option.isEmpty()) {
		    throw new ProductNotFound("Product Not Found By Id");
		}else {
			prod = option.get();
			prod.setQuantity(prod.getQuantity()-qty);
             
		    prod=productRepository.save(prod);
		}
		
		return prod;
	}

}
