package com.cg.exception;

public class ProductNotFound extends Exception{

	public ProductNotFound(String msg) {
		super(msg);
	}
}
