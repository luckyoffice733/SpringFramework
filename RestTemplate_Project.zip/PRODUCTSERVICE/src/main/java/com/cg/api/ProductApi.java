package com.cg.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.exception.ProductNotFound;
import com.cg.service.ProductService;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/api")
public class ProductApi {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping("/products")
	public Long addProduct(@RequestBody Product product) {
		return productService.addProduct(product);
	}
	
	@GetMapping("/products")
	public List<Product>  getAllProduct() throws ProductNotFound{
		return productService.getAllProducts();
	}
	
	@GetMapping("/products/{id}")//http://localhost:9090/api/products/1
	public Product getProductById(@PathVariable long id) throws ProductNotFound {
		return productService.getProductById(id);
	}
	
	@PutMapping("/products/{id}/{qty}")
	public Product updateProductQty(@PathVariable long id,@PathVariable long qty) throws ProductNotFound {
	  return productService.updateProductQuantity(id,qty);
	}
	
	
	
	
	

}
