package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.ResponseDTO;
import com.cg.entity.Order;
import com.cg.exception.OrderNotFoundException;
import com.cg.service.OrderService;

@RestController
@RequestMapping("/api")
public class OrderController {
	
	@Autowired
	private OrderService orderService;

	@PostMapping("/orders")
	public Long issueOrder(@RequestBody Order order) {
		return orderService.addOrder(order);
	}
	
	@GetMapping("/orders")
	public List<Order> getAllOrders() throws OrderNotFoundException{
		return orderService.getAllOrders();
	}
	@GetMapping("/orders/{id}")
	public Order getOrderById(@PathVariable Long id) throws OrderNotFoundException {
		return orderService.getOrderById(id);
	}
	
	@GetMapping("/orderWithProduct/{id}") //http://localhost:9092/api/orderWithProduct/1
	public ResponseDTO getOrderAndProductDetailsById(@PathVariable Long id) throws OrderNotFoundException {
		return orderService.getOrderAndProductById(id);
	}

	
}
