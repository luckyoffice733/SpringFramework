package com.cg.service;

import com.cg.entity.UserInfo;

public interface UserInfoService {
	public String addUser(UserInfo userInfo);
}
