package com.cg.entity;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;

@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;
	
	@NotEmpty(message = "Name field cannot be empty")
	@Pattern(regexp = "[a-zA-Z]{6,10}",message = "Name should be contain min 6  and max 10, Should not contains digits")
	private String name;
	
	//@NotEmpty(message = "Email field cannot be empty")
	@NotBlank(message = "Email field cannot be blank")
	@NotNull(message = "Email field cannot be null")
	@Email(message = "Please Enter an Valid Emaild Address\r\n"
			+ "")
	private String email;
	
	@NotNull(message = "DateOfBirth field cannot be null")
	@PastOrPresent(message = "Date Of birth should be present or past date")
	private LocalDate dateOfBirth;
	
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	
	
	
}
