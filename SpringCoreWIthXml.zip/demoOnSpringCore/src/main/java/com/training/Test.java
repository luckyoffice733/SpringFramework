package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		App aobj=	context.getBean(App.class,"ap");
		String msg =aobj.sayHello();
		System.out.println(msg);
	}
}
