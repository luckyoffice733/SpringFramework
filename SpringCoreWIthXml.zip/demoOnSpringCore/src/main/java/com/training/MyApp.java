package com.training;

public interface MyApp { 
	
    public String sayHello();

}
