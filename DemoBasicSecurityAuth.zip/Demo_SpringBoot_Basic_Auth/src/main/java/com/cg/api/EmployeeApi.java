package com.cg.api;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeApi {

	@GetMapping("/employee")  //http://localhost:5733/api/employee
	public String showMsg() {
		return "Welcome to SpringBoot Security";
	}
	
	@GetMapping("/employees")//http://localhost:5733/api/employees
	public List<String> fetchAllEmployeeNames() {
		return List.of("tom","jerry","oogi","scooby","pokemon");
	}
	
}
