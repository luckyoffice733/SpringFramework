package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.training.bean.Employee;

@SpringBootApplication
public class DemoOnSpringBootEnvironmentApplication implements CommandLineRunner {

	@Autowired
	private Employee employee;
	
	@Autowired
	private Environment environment;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootEnvironmentApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Employee Details are:");
		System.out.println(employee);
		
		System.out.println("Data from properties using envrionment");
		System.out.println("Employee name: "+environment.getProperty("en"));
		System.out.println("Employee Sal: "+environment.getProperty("esal"));
		System.out.println("Employee eid: "+environment.getProperty("eid"));
	}

}
