package com.training.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@NoArgsConstructor
public class Employee {

	@Value("${eid}")
	private long empId;
	@Value("${en}")
	private String empName;
	@Value("${esal}")
	private double empSal;
	
	
	
	
}
