package com.cg.exception;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {
	
	@Autowired
	private Environment  env;
	
	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ErrorResponse> handleExceptions(CustomerNotFoundException ex){
		String msg=env.getProperty(ex.getMessage());
		ErrorResponse errResp= new ErrorResponse();
		errResp.setErrorMessage(msg);
		errResp.setErrorCode(HttpStatus.NOT_FOUND.value());
		errResp.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<>(errResp,HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex){
		String msg=env.getProperty("General.EXCEPTION_MESSAGE");
		ErrorResponse errResp= new ErrorResponse();
		errResp.setErrorMessage(msg);
		errResp.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		errResp.setTimeStamp(LocalDateTime.now());
		
		return new ResponseEntity<>(errResp,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	
	

}
