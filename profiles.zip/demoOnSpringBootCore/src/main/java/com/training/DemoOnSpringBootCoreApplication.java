package com.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.bean.Employee;
import com.training.bean.Message;

@SpringBootApplication
//@ComponentScan(basePackages = {"com.training.bean"})
public class DemoOnSpringBootCoreApplication  implements CommandLineRunner{

	@Autowired
	private Employee employee;
	
	@Autowired
	private Message mg;	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootCoreApplication.class, args);
		System.out.println("welcome to spring boot");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(employee);
		System.out.println(mg.getMsg());
		
		List<String> al = mg.getFruits();
		System.out.println("size: "+al.size());
		System.out.println(al);
		
		al.forEach(System.out::println);
	}

}
