package com.training.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;


//@Profile("dev")
@Component
public class Employee {
	
	//@Value("1212")
	@Value("${eid}")   //reading the key value from the application.properties
	
	//@Value("${eid_dev}")
	private long empId;
	//@Value("smith")
	@Value("${en}")
	//@Value("${en1_dev}")
	private  String empName;
	//@Value("5000")
	@Value("${sal}")
	//@Value("${es_dev}")
	private  double empSal;
	
	
	
	
	public Employee(long empId, String empName, double empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getEmpId() {
		return empId;
	}
	public void setEmpId(long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	
	

}
