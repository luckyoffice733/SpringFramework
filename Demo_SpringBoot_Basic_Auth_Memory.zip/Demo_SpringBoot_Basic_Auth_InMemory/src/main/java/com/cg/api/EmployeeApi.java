package com.cg.api;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EmployeeApi {

	@GetMapping("/employee")  //http://localhost:5733/api/employee
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String showMsg() { //Martin
		return "Welcome to SpringBoot Security";
	}
	
	@GetMapping("/employees")//http://localhost:5733/api/employees
	@PreAuthorize("hasAuthority('ROLE_USER')")
	public List<String> fetchAllEmployeeNames() {//JOHN
		return List.of("tom","jerry","oogi","scooby","pokemon");
	}
	
}
