package com.training;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.NoArgsConstructor;

@Component
@Data
@NoArgsConstructor
public class Message {
    
	@Value("${msg1}")
	private String m1;
	
	@Value("${msg2}")
	private String m2;
	
	@Value("${msg3}")
	private String m3;
}
