package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoOnSpringBootYamlApplication  implements CommandLineRunner{

	@Autowired
	private Message message;
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootYamlApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(message.getM1()+" "+message.getM2()+" "+message.getM3());
	}

	
	
}
