package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.CustomerDTO;
import com.cg.entity.Customer;
import com.cg.exception.CustomerNotFoundException;
import com.cg.service.CustomerService;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

@RestController
@Validated
public class CustomerController {
	
	@Autowired
	private Environment env;
	
	@Autowired
	private CustomerService customerService;
	
	
	@PostMapping("/customer")//http://localhost:2024/customer
	public ResponseEntity<String>  addCustomer(@Valid @RequestBody CustomerDTO cust) {
		   Long  id= customerService.addCustomer(cust);
		   String msg="Record inserted successfully : "+id;
		   return new ResponseEntity<>(msg,HttpStatus.ACCEPTED);
	}  
	
	@GetMapping("/customers")//http://localhost:2024/customers
	public ResponseEntity<List<CustomerDTO>> getAllCustomer() throws CustomerNotFoundException{
	  List<CustomerDTO> allCust=customerService.getAllCustomers();
	  return new ResponseEntity<>(allCust,HttpStatus.OK);
	}
	  
	@GetMapping("/customer/{id}")
	public ResponseEntity<CustomerDTO> getCustomerById(
	    @Min(value = 1,message = "min value is 1 ") @Max(value = 100,message="max value range is 100")
		@PathVariable("id") long id) throws CustomerNotFoundException{
		CustomerDTO cust= customerService.getCustomerById(id); 
		
		return new ResponseEntity<>(cust,HttpStatus.OK);
	}
	
	@DeleteMapping("/customer/{id}")
	public ResponseEntity<String> deleteCustomerById(@PathVariable("id") long id) throws CustomerNotFoundException{
		customerService.deleteCustomer(id);
		String msg=env.getProperty("API.DELETED_SUCCESSFULLY");
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
	
	@PutMapping("/customer/{id}/{email}")
	public ResponseEntity<String> updateCustomerById(@PathVariable long id, @PathVariable String email) throws CustomerNotFoundException{
		customerService.updateCustomer(id, email);
		String msg=env.getProperty("API.UPDATED_SUCCESS");
		return new ResponseEntity<>(msg,HttpStatus.OK);
	}
	

}
