package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.entity.Customer;
import com.training.exception.CustomerNotFoundException;
import com.training.repo.CustomerRepository;

//@Component
@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository cRepository;//has-a relation

	@Override
	public Long addCustomer(Customer cust) {
		Customer cobj=    cRepository.save(cust);
		return cobj.getCustomerId();
	}

	@Override
	public List<Customer> getAllCustomers() throws CustomerNotFoundException{
		// TODO Auto-generated method stub
		List<Customer> al=cRepository.findAll();
		if(al.isEmpty()) {
			throw new CustomerNotFoundException("Customers Not Found ....!");
		}else {
			return al;
		}
	}

	@Override
	public Customer searchCustomerById(long id) throws CustomerNotFoundException {
		  Optional<Customer> optal=  cRepository.findById(id); 
		  Customer  cust =optal.orElseThrow(()->new CustomerNotFoundException("Customer Not Found Based on Id"));
		  
		//return optal.get();
		  return cust;
	}

	@Override
	public void deleteCustomer(long id) throws CustomerNotFoundException{
		 Optional<Customer> optal=  cRepository.findById(id); 
		 Customer  cust =optal.orElseThrow(()->new CustomerNotFoundException("Customer Not Found Based on Id"));
		  cRepository.deleteById(cust.getCustomerId());
	}

	@Override
	public void updateCustomer(Customer cust) throws CustomerNotFoundException {//new data
		// TODO Auto-generated method stub
		 Optional<Customer> optal=  cRepository.findById(cust.getCustomerId()); 
		 Customer  cobj =optal.orElseThrow(()->new CustomerNotFoundException("Customer Not Found Based on Id"));
		 
		 cobj.setDateOfBirth(cust.getDateOfBirth());
         cobj.setEmailId(cust.getEmailId());
         cobj.setName(cust.getName());
		 
		cRepository.save(cobj);
	}
	
	
	
	

}
