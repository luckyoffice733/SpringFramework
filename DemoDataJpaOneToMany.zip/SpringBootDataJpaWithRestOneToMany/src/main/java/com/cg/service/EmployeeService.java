package com.cg.service;

import java.util.List;

import com.cg.entity.Employee;

public interface EmployeeService {
	
	public Long addEmployee(Employee emp);
     public List<Employee> getEmployees();
}
