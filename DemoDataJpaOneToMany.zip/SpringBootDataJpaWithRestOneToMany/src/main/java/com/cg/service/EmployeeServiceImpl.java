package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Employee;
import com.cg.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepo emRepo;
	

	@Override
	public Long addEmployee(Employee emp) {
	    Employee eobj= emRepo.save(emp);
	    return eobj.getEmpId();
	}


	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return  emRepo.findAll();
	}

}
