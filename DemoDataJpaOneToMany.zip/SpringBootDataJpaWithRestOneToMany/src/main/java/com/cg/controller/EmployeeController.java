package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Employee;
import com.cg.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
 
	@Autowired
	private EmployeeService emService;
	
	@PostMapping("/employee") //http://localhost:9000/api/employee
	public String addEmployee(@RequestBody Employee emp) {
		long id =emService.addEmployee(emp);
		return "Record inserted : "+id;
	}
	
	//@RequestMapping(method = RequestMethod.GET,name = "/employees")
	@GetMapping("/employees")
	public List<Employee> listEmployees() {
		return emService.getEmployees();
	}
	
}
