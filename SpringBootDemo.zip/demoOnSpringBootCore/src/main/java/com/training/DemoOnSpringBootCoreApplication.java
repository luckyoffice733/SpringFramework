package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoOnSpringBootCoreApplication  implements CommandLineRunner {

	@Autowired
	private Employee employee;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootCoreApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(employee.getEmpId()+" "+employee.getEmpName()+" "+employee.getEmpSal());
	}

}
