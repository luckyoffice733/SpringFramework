package com.training;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.entity.Customer;
import com.training.repo.CustomerRepository;

@SpringBootApplication
public class DemoOnSpringBootDataJpa1Application  implements CommandLineRunner{

	@Autowired
	private CustomerRepository cRepo;
	
	
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootDataJpa1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Customer c = new Customer();
		c.setEmailId("johon01@cg.com");
		c.setName("john");
		
		String dob ="2003-11-01";
		LocalDate ld = LocalDate.parse(dob);
		c.setDateOfBirth(ld);
		
		cRepo.save(c);
		
		
	}
	
	
	

}
