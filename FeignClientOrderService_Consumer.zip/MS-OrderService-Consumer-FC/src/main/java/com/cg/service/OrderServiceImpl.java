package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.clients.ExampleOnFeignClientConsumer;
import com.cg.dto.Product;
import com.cg.dto.ResponseDTO;
import com.cg.entity.Order;
import com.cg.exception.OrderNotFoundException;
import com.cg.repo.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderRepository oRepository;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private ExampleOnFeignClientConsumer eonFC;

	@Override
	public Long addOrder(Order order) {
		// TODO Auto-generated method stub
		String pid = String.valueOf(order.getProductId());
		String qty = String.valueOf(order.getQuantity());

		//Replacing restTemplate Code with feignClient

		//calling the delcarative Feign Client abstract method
		eonFC.consumingPutRequestFromProvider(pid, qty);
		
		/*
		 * //consuming ProductService put Requesting String
		 * url="http://localhost:6091/api/products/{id}/{qty}";
		 * 
		 * 
		 * Map<String,String> hm = new HashMap<>(); hm.put("id", pid);
		 * hm.put("qty",qty);
		 * 
		 * 
		 * restTemplate.put(url,Product.class,pid,qty);
		 */

		// System.out.println(p);

		// restTemplate.exchange(url,HttpMethod.PUT,P);
		return oRepository.save(order).getOrderId();
	}

	@Override
	public List<Order> getAllOrders() throws OrderNotFoundException {
		// TODO Auto-generated method stub
		List<Order> allOrders = oRepository.findAll();
		if (allOrders.isEmpty()) {
			throw new OrderNotFoundException("Order Records NOt Found");
		}
		return allOrders;
	}

	@Override
	public Order getOrderById(Long id) throws OrderNotFoundException {
		// TODO Auto-generated method stub
		Optional<Order> option = oRepository.findById(id);
		if (option.isEmpty()) {
			throw new OrderNotFoundException("No Recor found based on order id ");
		}

		return option.get();
	}

	@Override
	public ResponseDTO getOrderAndProductById(long id) throws OrderNotFoundException {
		ResponseDTO responseDTO = new ResponseDTO();
		Optional<Order> option = oRepository.findById(id);
		if (option.isEmpty()) {
			throw new OrderNotFoundException("No Recor found based on order id ");
		} else {
			Order order = option.get();
			long pid = order.getProductId();

			/*
			 * // based on the product id we consuming get request from the productService
			 * String url = "http://localhost:6091/api/products/{id}"; // consuming Product
			 * product = restTemplate.getForObject(url, Product.class, pid);
			 */
			
			//based on the product id we consuming get request from the productService
			//replacing the restTempalte code with FeignClient
			Product product = eonFC.consumingGetRequestFromProvider(pid);

			responseDTO.setOrder(order);
			responseDTO.setProduct(product);
		}

		return responseDTO;
	}

}
