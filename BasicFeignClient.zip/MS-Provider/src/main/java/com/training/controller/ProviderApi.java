package com.training.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/FCprovider/")
public class ProviderApi {

	@GetMapping("/msg")//http://localhost:7091/FCprovider/msg
	public String showMsg() {
		return "FROM  MS-PROVIDER Welcome to Feign Client";
	}
	
	
}
