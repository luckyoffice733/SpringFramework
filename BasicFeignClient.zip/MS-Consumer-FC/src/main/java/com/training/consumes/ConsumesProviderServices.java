package com.training.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "MS-Provider",url = "http://localhost:7091/")
public interface ConsumesProviderServices {

	@GetMapping("/FCprovider/msg") //http://localhost:7091/FCprovider/msg
	public String consumingShowMsg(); //declarative method
}
