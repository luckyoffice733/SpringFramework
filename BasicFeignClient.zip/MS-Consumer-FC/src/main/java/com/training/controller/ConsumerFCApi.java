package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.consumes.ConsumesProviderServices;

@RestController
@RequestMapping("/api")
public class ConsumerFCApi {
	
	@Autowired
	private ConsumesProviderServices cServices;
	
	
    //http://localhost:7092/api/consume
	@GetMapping("/consume")
	public String getDataFromProvider() {
		
		String m1=cServices.consumingShowMsg();
		
		return "FROM MS-CONSUMER ->Received the Provider --> "+m1;
	}
	
}
