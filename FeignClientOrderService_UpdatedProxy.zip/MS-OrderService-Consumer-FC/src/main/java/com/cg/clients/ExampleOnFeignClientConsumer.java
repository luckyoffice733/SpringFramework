package com.cg.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.cg.entity.Product;//importing from the MS-ProductService-Provider as dependency

@FeignClient(name = "MS-ProductService-Provider",url="http://localhost:6091/api")
public interface ExampleOnFeignClientConsumer {

	@PutMapping("/products/{id}/{qty}")//http://localhost:6091/api/products/{id}/{qty}
	public Product consumingPutRequestFromProvider(@PathVariable String id,@PathVariable String qty);
	
	@GetMapping("/products/{id}")//http://localhost:6091/api/products/{id}
	public Product consumingGetRequestFromProvider(@PathVariable long id);
	
}
