package com.cg.dto;

import com.cg.entity.Order;
import com.cg.entity.Product;//import the proxy the project act as dependency

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseDTO {

	private Order  order;
	private Product product;
}
