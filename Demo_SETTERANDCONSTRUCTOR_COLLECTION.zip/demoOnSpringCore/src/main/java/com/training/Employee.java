package com.training;

import java.util.List;
import java.util.Map;

public class Employee {
       
	private Integer empId;
	private String empName;
	private double empSal;
	
	private List<String> mobileNo; 
	
	private Map<String,Integer> roles;

	/*
	 * public Employee(Integer empId, String empName, double empSal, List<String>
	 * mobileNo) { super(); this.empId = empId; this.empName = empName; this.empSal
	 * = empSal; this.mobileNo = mobileNo; }
	 * 
	 */

	public Employee(Integer empId, String empName, double empSal, List<String> mobileNo, Map<String, Integer> roles) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.mobileNo = mobileNo;
		this.roles = roles;
	}



	public Map<String, Integer> getRoles() {
		return roles;
	}



	public void setRoles(Map<String, Integer> roles) {
		this.roles = roles;
	}



	public List<String> getMobileNo() {
		return mobileNo;
	}



	public void setMobileNo(List<String> mobileNo) {
		this.mobileNo = mobileNo;
	}



	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	/*
	 * public Employee(Integer empId, String empName, double empSal) { super();
	 * this.empId = empId; this.empName = empName; this.empSal = empSal; }
	 */


	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", mobileNo=" + mobileNo
				+ ", roles=" + roles + "]";
	}
	
	
	
	
}
