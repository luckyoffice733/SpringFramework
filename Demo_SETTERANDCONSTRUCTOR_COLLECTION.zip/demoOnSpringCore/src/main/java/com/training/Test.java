package com.training;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		App aobj=	context.getBean(App.class,"ap");
		String msg =aobj.sayHello();
		System.out.println(msg);
		
		/*
		 * Employee e =context.getBean(Employee.class,"emp");
		 * System.out.println("Setting Injection values are :");
		 * System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getEmpSal());
		 */
		
		Employee e =context.getBean(Employee.class,"emp");
		System.out.println("Construction Injection values are :");
		System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getEmpSal());
		 List<String> mns1=e.getMobileNo();
		System.out.println("Employee Mobile Numbers");
		mns1.forEach(System.out::println);
		
		
		//construtor injection
		/*
		 * Employee e1 =context.getBean(Employee.class,"emp1");
		 * System.out.println("Construction Injection values are :");
		 * System.out.println(e1.getEmpId()+" "+e1.getEmpName()+" "+e1.getEmpSal());
		 * List<String> mns=e1.getMobileNo();
		 * System.out.println("Employee Mobile Numbers");
		 * mns.forEach(System.out::println);
		 * 
		 * System.out.println("Employee roles :"); Map<String,Integer> hm=e1.getRoles();
		 * for(Entry<String, Integer> et :hm.entrySet()) {
		 * System.out.println(et.getKey()+" "+et.getValue()); }
		 */
		
	}
}
