package com.cg.service;

import com.cg.entity.Employee;

public interface EmployeeService {
	
	public Long addEmployee(Employee emp);

}
