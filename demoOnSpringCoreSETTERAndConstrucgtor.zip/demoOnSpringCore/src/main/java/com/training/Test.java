package com.training;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		App aobj=	context.getBean(App.class,"ap");
		String msg =aobj.sayHello();
		System.out.println(msg);
		
		/*
		 * Employee e =context.getBean(Employee.class,"emp");
		 * System.out.println("Setting Injection values are :");
		 * System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getEmpSal());
		 */
		Employee e1 =context.getBean(Employee.class,"emp1");
		System.out.println("Construction Injection values are :");
		System.out.println(e1.getEmpId()+" "+e1.getEmpName()+" "+e1.getEmpSal());
	}
}
