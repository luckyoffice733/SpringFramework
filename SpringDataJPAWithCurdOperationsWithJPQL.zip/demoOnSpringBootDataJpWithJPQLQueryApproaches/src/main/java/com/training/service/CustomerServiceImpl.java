package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.entity.Customer;
import com.training.repo.CustomerRepository;

//@Component
@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository cRepository;//has-a relation

	@Override
	public Long addCustomer(Customer cust) {
		Customer cobj=    cRepository.save(cust);
		return cobj.getCustomerId();
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return  cRepository.findAll();
	}

	@Override
	public Customer searchCustomerById(long id) {
		  Optional<Customer> optal=  cRepository.findById(id);
		return optal.get();
	}

	@Override
	public void deleteCustomer(long id) {
		// TODO Auto-generated method stub
		Customer cobj =searchCustomerById(id);
		if(cobj!=null) {
			cRepository.deleteById(cobj.getCustomerId());
			System.out.println("Record Deleted Succcessfully");
		}else {
			System.out.println("Record Does not exist based on id:");
		}
	}

	@Override
	public void updateCustomer(Customer cust) {//new data
		// TODO Auto-generated method stub
		Customer cobj =searchCustomerById(cust.getCustomerId());//old record
		if(cobj!=null) {
			cobj.setDateOfBirth(cust.getDateOfBirth());
			cobj.setEmailId(cust.getEmailId());
			cobj.setName(cust.getName());
			cRepository.save(cobj);//based on id record already exist it will update the record
			
	     }else {
				System.out.println("Record Does not exist based on id:");
			}
		
	}

	@Override
	public Customer searchCustomerByEmail(String em) {
	
		Customer cSearchEmail=cRepository.findByEmailId(em);
		return cSearchEmail;
		
	}
	
	
	
	

}
