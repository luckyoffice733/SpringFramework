package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.entity.Customer;
import com.training.service.CustomerService;

@SpringBootApplication
public class DemoOnSpringBootDataJpWithJpqlQueryApproachesApplication  implements CommandLineRunner{

	@Autowired
	private CustomerService customerService;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootDataJpWithJpqlQueryApproachesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		String em="smith1@cg.com";
		Customer  cobj=customerService.searchCustomerByEmail(em);
		System.out.println(cobj);
	}

}
