package com.training.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.Customer;
import com.training.exception.CustomerNotFoundException;
import com.training.service.CustomerService;

@RestController
@RequestMapping("/api")
public class CustomerController {
	
	/*
	 * @Autowired private CustomerService cService;
	 */
	private CustomerService customerService;
	
	/*
	 * @Autowired public CustomerController(CustomerService customerService) {
	 * this.customerService=customerService; }
	 */
	
	public CustomerService getCustomerService() {
		return customerService;
	}

    @Autowired
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

	
	
	
     @PostMapping("/customer")	//http://localhost:8000/api/customer
	public String  addCustomer(@RequestBody Customer cust) {
	Long id=customerService.addCustomer(cust);
	return "Record is inserted : "+id;
	}
	
     
    

	@GetMapping("/customers") //http://localhost:8000/api/customers
    public List<Customer>  getCustomerRecords() throws CustomerNotFoundException{
    	List<Customer> al = new ArrayList<>();
    	
    	al= customerService.getAllCustomers();
    	
    	return al;
    }
     
     
    @GetMapping("/customer/{id}") //http://localhost:8000/customer/2
    public Customer getCustomerById(@PathVariable("id")  long id) throws CustomerNotFoundException {
    	Customer c=null;
    			
    	c=customerService.searchCustomerById(id);
    			
    			return c;
    }
    
    @DeleteMapping("/customer/{id}") //http://localhost:8000/customer/2
    public void deleteCustomer(@PathVariable("id")  long id) throws CustomerNotFoundException {
    	
    			
        customerService.deleteCustomer(id);
    			
    		
    }
     
    
    @PutMapping("/customer")	//http://localhost:8000/api/customer
   	public void  updateCustomer(@RequestBody Customer newCust) throws CustomerNotFoundException { //pass New Data with existing id
   	   
    	customerService.updateCustomer(newCust);
   	   
   	}
     

}
