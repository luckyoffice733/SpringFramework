package com.training.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {

	
	
	@ExceptionHandler(CustomerNotFoundException.class)
	public ErrorResponse handlerException(CustomerNotFoundException cne) {
		
		ErrorResponse eResponse = new ErrorResponse();
		
		String msg = cne.getMessage();
		int errorCode = HttpStatus.BAD_REQUEST.value();
		
		eResponse.setTimeStamp(LocalDateTime.now());
		eResponse.setErrorCode(errorCode);
		eResponse.setErrorMsg(msg); 
		return eResponse;
		
		
	}
	
	@ExceptionHandler(Exception.class)
      public ErrorResponse handlerMultipleException(Exception cne) {
		
		ErrorResponse eResponse = new ErrorResponse();
		
		String msg = "Something Went Wrong !..Please Try Again ";
		int errorCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
		
		eResponse.setTimeStamp(LocalDateTime.now());
		eResponse.setErrorCode(errorCode);
		eResponse.setErrorMsg(msg); 
		return eResponse;
		
		
	}
	
	
	
	
	
	
	
}
