package com.training.exception;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
public class ErrorResponse {

	private LocalDateTime timeStamp;
	private int errorCode;
	private  String errorMsg;
	
}
