package com.cg.exception;

public class CGBankException extends Exception {
	private static final long serialVersionUID = 1L;

	public CGBankException(String message) {
		super(message);
	}
}
