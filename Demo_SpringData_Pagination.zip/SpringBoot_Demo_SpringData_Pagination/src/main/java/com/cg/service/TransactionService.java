package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.TransactionDTO;
import com.cg.exception.CGBankException;

public interface TransactionService {
	public List<TransactionDTO> getAllTransaction(Integer pageNo, Integer pageSize) throws CGBankException;

	public List<TransactionDTO> getAllTransactionByTransactionDateAfter(LocalDate transactionDate, Integer pageNo,
			Integer pageSize) throws CGBankException;
}