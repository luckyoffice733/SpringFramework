package com.training.entity;

import java.time.LocalDate;

import org.hibernate.annotations.Collate;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="customer_tab")
@Data
@NoArgsConstructor
@NamedQuery(name="Customer.findNameByEmail", query = "Select c from Customer c where c.emailId=:a")
public class Customer { //orm mapping
     
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long customerId;   //customer_id
	
	@Column(length = 30)
	private String emailId;   //email_Id
	
	@Column(length = 20)
	private String name;
	
	@Column
	private LocalDate dateOfBirth;  //date_of_birth
	
	
	
}
