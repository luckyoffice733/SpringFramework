package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.entity.Customer;
import com.training.service.CustomerService;

@SpringBootApplication
public class DemoOnSpringBootDataJpWithJpqlNamedQueryApplication implements CommandLineRunner{

	@Autowired
	private CustomerService customerService;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootDataJpWithJpqlNamedQueryApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Customer c=customerService.searchCustomerEmail("smith1@cg.com");
		System.out.println("using NamedQuery");
		System.out.println(c);
	}

}
