package com.cg.service;

import java.util.List;

import com.cg.entity.Product;
import com.cg.exception.ProductNotFound;

public interface ProductService {

	 public Long addProduct(Product product);
	 public List<Product> getAllProducts()  throws ProductNotFound;
	 public Product getProductById(Long id) throws ProductNotFound;
	 public Product updateProductQuantity(Long id, Long qty ) throws ProductNotFound;
	
}
