package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsOrderServiceConsumerFcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsOrderServiceConsumerFcApplication.class, args);
	}

}
